﻿In this zip can be found :

Previous order process form that has been used for this bga substrate
PDF file with clear information regarding board thickness and substrate stackup
Gerber files
